// انسخ بيانات تطبيق الويب من Firebase Console وضعها هنا قبل التشغيل.
// يجب أن يكون adminEmail هو بريد حساب الإدارة الذي أنشأته في Firebase Authentication.
const FIREBASE_CONFIG = {
  apiKey: "PUT_API_KEY_HERE",
  authDomain: "PUT_PROJECT_ID.firebaseapp.com",
  projectId: "PUT_PROJECT_ID",
  storageBucket: "PUT_PROJECT_ID.appspot.com",
  messagingSenderId: "PUT_SENDER_ID",
  appId: "PUT_APP_ID",
  adminEmail: "PUT_ADMIN_EMAIL_HERE"
};
