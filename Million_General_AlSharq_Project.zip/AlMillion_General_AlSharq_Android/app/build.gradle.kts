plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.generalalsharq.million"
    compileSdk = 36
    defaultConfig { applicationId = "com.generalalsharq.million"; minSdk = 23; targetSdk = 36; versionCode = 1; versionName = "1.0.0" }
}

dependencies { implementation("androidx.webkit:webkit:1.12.1") }
